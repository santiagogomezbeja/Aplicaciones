import { Client, ClientType, Order, OrderStatus, Material, Scrap } from '../types';
import { INITIAL_MATERIALS } from '../constants';

// Simulating database state
let clients: Client[] = [
  { id: 'c1', name: 'Artesanías Bogotá', email: 'contacto@artesanias.co', phone: '3001234567', type: ClientType.RECURRENT, ordersCount: 15, lastOrderDate: '2023-10-01' },
  { id: 'c2', name: 'Juan Pérez', email: 'juanperez@gmail.com', phone: '3109876543', type: ClientType.OCCASIONAL, ordersCount: 1, lastOrderDate: '2023-09-15' },
];

let orders: Order[] = [
  { id: 'o1', clientId: 'c1', description: '200 Llaveros Logo', status: OrderStatus.PRODUCTION, createdAt: '2023-10-20', totalPrice: 450000, materialId: 'm1' },
  { id: 'o2', clientId: 'c2', description: 'Topper Torta Cumpleaños', status: OrderStatus.WAITING_APPROVAL, createdAt: '2023-10-22', totalPrice: 35000, materialId: 'm3' },
  { id: 'o3', clientId: 'c1', description: 'Cajas Recordatorio', status: OrderStatus.DESIGN, createdAt: '2023-10-23', totalPrice: 120000, materialId: 'm1' },
];

let materials: Material[] = [...INITIAL_MATERIALS];

let scraps: Scrap[] = [
  { id: 's1', materialId: 'm1', width: 50, height: 40, notes: 'Restante de corte circular' },
  { id: 's2', materialId: 'm3', width: 30, height: 180, notes: 'Faja lateral' },
];

export const getClients = () => clients;
export const getOrders = () => orders;
export const getMaterials = () => materials;
export const getScraps = () => scraps;

export const addClient = (client: Client) => {
  clients = [...clients, client];
};

export const updateOrderStatus = (orderId: string, newStatus: OrderStatus) => {
  orders = orders.map(o => o.id === orderId ? { ...o, status: newStatus } : o);
};

export const addOrder = (order: Order) => {
  orders = [...orders, order];
  // Update client stats logic
  const clientIndex = clients.findIndex(c => c.id === order.clientId);
  if (clientIndex >= 0) {
    const client = clients[clientIndex];
    const newCount = client.ordersCount + 1;
    const newType = newCount > 3 ? ClientType.RECURRENT : ClientType.OCCASIONAL;
    clients[clientIndex] = {
      ...client,
      ordersCount: newCount,
      lastOrderDate: new Date().toISOString().split('T')[0],
      type: newType
    };
  }
};

export const useMaterial = (materialId: string, isFullSheet: boolean, scrapId?: string) => {
  if (isFullSheet) {
    materials = materials.map(m => m.id === materialId ? { ...m, fullSheets: Math.max(0, m.fullSheets - 1) } : m);
  } else if (scrapId) {
    scraps = scraps.filter(s => s.id !== scrapId);
  }
};

export const addScrap = (scrap: Scrap) => {
  scraps = [...scraps, scrap];
};