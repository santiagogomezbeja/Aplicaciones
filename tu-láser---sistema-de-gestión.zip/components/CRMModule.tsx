import React, { useState, useEffect } from 'react';
import { Search, UserPlus, History, Star, AlertTriangle } from 'lucide-react';
import { getClients, addClient } from '../services/dataService';
import { Client, ClientType } from '../types';

const CRMModule: React.FC = () => {
  const [clients, setClients] = useState<Client[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  
  // New Client Form State
  const [newClientName, setNewClientName] = useState('');
  const [newClientEmail, setNewClientEmail] = useState('');
  const [newClientPhone, setNewClientPhone] = useState('');

  useEffect(() => {
    setClients(getClients());
  }, []);

  const handleAddClient = (e: React.FormEvent) => {
    e.preventDefault();
    const newClient: Client = {
      id: Date.now().toString(),
      name: newClientName,
      email: newClientEmail,
      phone: newClientPhone,
      type: ClientType.OCCASIONAL, // Default to occasional
      ordersCount: 0,
      lastOrderDate: 'Nunca'
    };
    addClient(newClient);
    setClients(getClients());
    setShowAddModal(false);
    setNewClientName('');
    setNewClientEmail('');
    setNewClientPhone('');
  };

  const filteredClients = clients.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-800">Gestión de Clientes (CRM)</h2>
        <button 
          onClick={() => setShowAddModal(true)}
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-indigo-700 transition"
        >
          <UserPlus size={18} /> Nuevo Cliente
        </button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-3 text-slate-400" size={20} />
        <input 
          type="text" 
          placeholder="Buscar cliente por nombre o correo..." 
          className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredClients.map(client => (
          <div key={client.id} className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 hover:shadow-md transition">
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-lg text-slate-800">{client.name}</h3>
                  {client.type === ClientType.RECURRENT ? (
                    <span className="bg-green-100 text-green-700 text-xs px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                      <Star size={10} fill="currentColor" /> Cliente Recurrente (Tipo A)
                    </span>
                  ) : (
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-0.5 rounded-full font-bold">
                      Cliente Ocasional (Tipo B)
                    </span>
                  )}
                </div>
                <div className="text-slate-500 text-sm mt-1">
                  <p>{client.email} • {client.phone}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-slate-600">Pedidos Totales</p>
                <p className="text-xl font-bold text-slate-800">{client.ordersCount}</p>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-50 flex justify-between items-center text-sm">
              <div className="flex items-center gap-2 text-slate-500">
                <History size={16} /> Último pedido: {client.lastOrderDate}
              </div>
              {client.type === ClientType.OCCASIONAL && (
                <div className="flex items-center gap-2 text-amber-600 bg-amber-50 px-3 py-1 rounded-md">
                   <AlertTriangle size={14} /> Sugerencia: Enviar mensaje de seguimiento
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl p-6 w-full max-w-md">
            <h3 className="text-xl font-bold mb-4">Registrar Nuevo Cliente</h3>
            <form onSubmit={handleAddClient} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Nombre</label>
                <input required type="text" value={newClientName} onChange={e => setNewClientName(e.target.value)} className="w-full border rounded p-2" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Email</label>
                <input required type="email" value={newClientEmail} onChange={e => setNewClientEmail(e.target.value)} className="w-full border rounded p-2" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Teléfono</label>
                <input required type="tel" value={newClientPhone} onChange={e => setNewClientPhone(e.target.value)} className="w-full border rounded p-2" />
              </div>
              <div className="flex justify-end gap-2 mt-6">
                <button type="button" onClick={() => setShowAddModal(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded">Cancelar</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">Guardar</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default CRMModule;