import React, { useState, useEffect } from 'react';
import { getOrders, updateOrderStatus, getClients } from '../services/dataService';
import { Order, OrderStatus } from '../types';
import { KANBAN_COLUMNS } from '../constants';
import { Clock, AlertTriangle, CheckCircle2 } from 'lucide-react';

const ProductionKanban: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [draggedOrderId, setDraggedOrderId] = useState<string | null>(null);

  useEffect(() => {
    setOrders(getOrders());
  }, []);

  const refreshOrders = () => {
    setOrders([...getOrders()]); // Force new reference
  };

  const getClientName = (id: string) => {
    const client = getClients().find(c => c.id === id);
    return client ? client.name : 'Cliente Desconocido';
  };

  const handleDragStart = (e: React.DragEvent, orderId: string) => {
    setDraggedOrderId(orderId);
  };

  const handleDrop = (e: React.DragEvent, targetStatus: OrderStatus) => {
    e.preventDefault();
    if (draggedOrderId) {
      // Special logic for "Waiting Approval"
      const order = orders.find(o => o.id === draggedOrderId);
      if (order?.status === OrderStatus.WAITING_APPROVAL && targetStatus === OrderStatus.PRODUCTION) {
         if(!window.confirm("¿El cliente YA aprobó el diseño? Esta acción es irreversible.")) {
            return;
         }
      }

      updateOrderStatus(draggedOrderId, targetStatus);
      refreshOrders();
      setDraggedOrderId(null);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const getStatusColor = (status: OrderStatus) => {
    if (status === OrderStatus.WAITING_APPROVAL) return 'bg-red-100 border-red-300';
    if (status === OrderStatus.PRODUCTION) return 'bg-blue-100 border-blue-300';
    if (status === OrderStatus.READY) return 'bg-green-100 border-green-300';
    return 'bg-white border-slate-200';
  };

  return (
    <div className="h-full flex flex-col">
      <div className="mb-6 flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-800">Flujo de Producción</h2>
        <div className="flex gap-4 text-sm">
            <div className="flex items-center gap-2"><span className="w-3 h-3 bg-red-500 rounded-full"></span> Bloqueado (Falta OK)</div>
            <div className="flex items-center gap-2"><span className="w-3 h-3 bg-blue-500 rounded-full"></span> En Corte</div>
        </div>
      </div>
      
      <div className="flex-1 overflow-x-auto">
        <div className="flex gap-4 min-w-[1000px] h-full pb-4">
          {KANBAN_COLUMNS.map(col => (
            <div key={col.id} className="flex-1 min-w-[250px] bg-slate-100 rounded-xl p-4 flex flex-col">
              <h3 className="font-bold text-slate-700 mb-4 flex justify-between items-center">
                {col.title}
                <span className="bg-slate-200 text-slate-600 text-xs px-2 py-1 rounded-full">
                  {orders.filter(o => col.statuses.includes(o.status)).length}
                </span>
              </h3>
              
              <div 
                className="flex-1 space-y-3"
                onDragOver={handleDragOver}
                onDrop={(e) => handleDrop(e, col.statuses[0])} // Drop into the first status of the column
              >
                {orders
                  .filter(o => col.statuses.includes(o.status))
                  .map(order => (
                    <div
                      key={order.id}
                      draggable
                      onDragStart={(e) => handleDragStart(e, order.id)}
                      className={`p-4 rounded-lg shadow-sm border cursor-grab active:cursor-grabbing hover:shadow-md transition ${getStatusColor(order.status)}`}
                    >
                      {order.status === OrderStatus.WAITING_APPROVAL && (
                        <div className="mb-2 text-xs font-bold text-red-600 flex items-center gap-1 uppercase">
                          <AlertTriangle size={12} /> Requiere Aprobación
                        </div>
                      )}
                      
                      <p className="font-bold text-slate-800 text-sm">{order.description}</p>
                      <p className="text-xs text-slate-500 mt-1">{getClientName(order.clientId)}</p>
                      
                      <div className="mt-3 flex justify-between items-center text-xs text-slate-400 border-t border-slate-200/50 pt-2">
                        <span className="flex items-center gap-1"><Clock size={12} /> {new Date(order.createdAt).toLocaleDateString()}</span>
                        <span className="font-semibold text-slate-600">${order.totalPrice.toLocaleString()}</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProductionKanban;