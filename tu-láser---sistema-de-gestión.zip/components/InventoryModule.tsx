import React, { useState, useEffect } from 'react';
import { Layers, Scissors, CheckCircle, AlertOctagon } from 'lucide-react';
import { getMaterials, getScraps, addScrap, useMaterial } from '../services/dataService';
import { Material, Scrap } from '../types';

const InventoryModule: React.FC = () => {
  const [materials, setMaterials] = useState<Material[]>([]);
  const [scraps, setScraps] = useState<Scrap[]>([]);
  const [activeTab, setActiveTab] = useState<'sheets' | 'scraps'>('sheets');

  // Logic to simulate usage check
  const [checkWidth, setCheckWidth] = useState<number>(0);
  const [checkHeight, setCheckHeight] = useState<number>(0);
  const [checkMaterialId, setCheckMaterialId] = useState<string>('');
  const [suggestion, setSuggestion] = useState<Scrap | null>(null);

  useEffect(() => {
    refreshInventory();
  }, []);

  const refreshInventory = () => {
    setMaterials(getMaterials());
    setScraps(getScraps());
    if (getMaterials().length > 0) setCheckMaterialId(getMaterials()[0].id);
  };

  const checkForScrap = () => {
    if (checkWidth <= 0 || checkHeight <= 0) return;
    
    // Find scrap that fits dimensions
    const validScrap = scraps.find(s => 
      s.materialId === checkMaterialId && 
      ((s.width >= checkWidth && s.height >= checkHeight) || (s.width >= checkHeight && s.height >= checkWidth))
    );

    setSuggestion(validScrap || null);
  };

  const handleUseSheet = (id: string) => {
    if(window.confirm('¿Confirmar uso de 1 lámina completa?')) {
        useMaterial(id, true);
        refreshInventory();
    }
  };

  const handleUseScrap = (id: string) => {
    if(window.confirm('¿Confirmar uso de este retazo?')) {
        useMaterial('', false, id);
        refreshInventory();
        setSuggestion(null);
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-800">Inventario Avanzado</h2>

      {/* Suggestion Engine */}
      <div className="bg-slate-800 text-white p-6 rounded-xl shadow-lg">
        <h3 className="font-bold text-lg mb-4 flex items-center gap-2"><Scissors size={20} /> Verificador de Retazos</h3>
        <p className="text-slate-300 text-sm mb-4">Antes de cortar una lámina nueva, verifica si existe un retazo útil.</p>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
          <div>
             <label className="block text-xs text-slate-400 mb-1">Material</label>
             <select 
               className="w-full bg-slate-700 border border-slate-600 rounded p-2 text-sm"
               value={checkMaterialId}
               onChange={(e) => setCheckMaterialId(e.target.value)}
             >
                {materials.map(m => <option key={m.id} value={m.id}>{m.name} {m.thickness}</option>)}
             </select>
          </div>
          <div>
            <label className="block text-xs text-slate-400 mb-1">Ancho (cm)</label>
            <input 
              type="number" 
              className="w-full bg-slate-700 border border-slate-600 rounded p-2 text-sm"
              value={checkWidth}
              onChange={e => setCheckWidth(Number(e.target.value))}
            />
          </div>
          <div>
            <label className="block text-xs text-slate-400 mb-1">Alto (cm)</label>
            <input 
              type="number" 
              className="w-full bg-slate-700 border border-slate-600 rounded p-2 text-sm"
              value={checkHeight}
              onChange={e => setCheckHeight(Number(e.target.value))}
            />
          </div>
          <button 
            onClick={checkForScrap}
            className="bg-indigo-500 hover:bg-indigo-600 text-white py-2 px-4 rounded font-medium transition"
          >
            Verificar
          </button>
        </div>

        {suggestion ? (
           <div className="mt-4 bg-green-900/50 border border-green-500/50 p-4 rounded text-green-200 flex justify-between items-center">
             <div>
                <p className="font-bold flex items-center gap-2"><CheckCircle size={18} /> ¡Retazo Encontrado!</p>
                <p className="text-sm mt-1">Dimensiones: {suggestion.width}x{suggestion.height} cm — {suggestion.notes}</p>
             </div>
             <button onClick={() => handleUseScrap(suggestion.id)} className="text-xs bg-green-700 hover:bg-green-600 px-3 py-1 rounded">Usar Retazo</button>
           </div>
        ) : (checkWidth > 0 && !suggestion) ? (
            <div className="mt-4 bg-slate-700/50 border border-slate-600 p-4 rounded text-slate-400 flex items-center gap-2">
                <AlertOctagon size={18} /> No hay retazos suficientes. Debes usar lámina completa.
            </div>
        ) : null}
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200">
        <button 
          onClick={() => setActiveTab('sheets')}
          className={`px-6 py-3 font-medium text-sm transition ${activeTab === 'sheets' ? 'border-b-2 border-indigo-600 text-indigo-600' : 'text-slate-500'}`}
        >
          Láminas Enteras
        </button>
        <button 
           onClick={() => setActiveTab('scraps')}
           className={`px-6 py-3 font-medium text-sm transition ${activeTab === 'scraps' ? 'border-b-2 border-indigo-600 text-indigo-600' : 'text-slate-500'}`}
        >
          Retazos (Scraps)
        </button>
      </div>

      {/* Lists */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        {activeTab === 'sheets' ? (
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-semibold">
              <tr>
                <th className="px-6 py-4">Material</th>
                <th className="px-6 py-4">Espesor</th>
                <th className="px-6 py-4">Dimensiones</th>
                <th className="px-6 py-4 text-center">Stock</th>
                <th className="px-6 py-4 text-right">Acción</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {materials.map(m => (
                <tr key={m.id} className="hover:bg-slate-50">
                  <td className="px-6 py-4 font-medium text-slate-800">{m.name}</td>
                  <td className="px-6 py-4">{m.thickness}</td>
                  <td className="px-6 py-4">{m.sheetWidth} x {m.sheetHeight} cm</td>
                  <td className="px-6 py-4 text-center">
                    <span className={`px-2 py-1 rounded-full text-xs font-bold ${m.fullSheets < 5 ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                      {m.fullSheets}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button onClick={() => handleUseSheet(m.id)} className="text-red-600 hover:text-red-800 font-medium text-xs">Descontar</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="p-6">
            {scraps.length === 0 ? (
                <p className="text-slate-500 text-center py-8">No hay retazos registrados.</p>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {scraps.map(s => {
                        const matName = materials.find(m => m.id === s.materialId)?.name || 'Desc.';
                        return (
                            <div key={s.id} className="border border-slate-200 rounded-lg p-4 bg-slate-50 relative group">
                                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition">
                                    <button onClick={() => handleUseScrap(s.id)} className="text-xs bg-white border shadow-sm px-2 py-1 rounded text-red-600 hover:bg-red-50">Usar</button>
                                </div>
                                <h4 className="font-bold text-slate-700">{matName}</h4>
                                <p className="text-2xl font-bold text-slate-800 my-2">{s.width} x {s.height} <span className="text-sm font-normal text-slate-500">cm</span></p>
                                <p className="text-xs text-slate-500 bg-white p-2 rounded border border-slate-100">{s.notes}</p>
                            </div>
                        )
                    })}
                </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default InventoryModule;