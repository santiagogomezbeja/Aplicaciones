import React, { useMemo } from 'react';
import { AlertCircle, TrendingUp, Users, ShoppingBag, Calendar } from 'lucide-react';
import { getOrders, getClients } from '../services/dataService';
import { OrderStatus } from '../types';

const Dashboard: React.FC = () => {
  const orders = getOrders();
  const clients = getClients();

  const totalSales = useMemo(() => orders.reduce((acc, order) => acc + order.totalPrice, 0), [orders]);
  const activeOrders = useMemo(() => orders.filter(o => o.status !== OrderStatus.DELIVERED && o.status !== OrderStatus.DRAFT).length, [orders]);
  
  const seasonalAlert = useMemo(() => {
    const month = new Date().getMonth() + 1; // 1-12
    if (month === 10 || month === 11) return { title: "Temporada Navideña", message: "Aumentar stock de MDF 3mm y Acrílico Rojo/Verde. Preparar diseños de bolas y pesebres." };
    if (month === 4) return { title: "Día de la Madre (Mayo)", message: "Preparar inventario de MDF para cajas y toppers." };
    if (month === 8) return { title: "Amor y Amistad (Sept)", message: "Stock de acrílico rojo y llaveros pareja." };
    return null;
  }, []);

  return (
    <div className="space-y-6">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800">Panel de Control Gerencial</h1>
        <p className="text-slate-500">Resumen operativo de Tu Láser</p>
      </header>

      {/* Seasonal Alert */}
      {seasonalAlert && (
        <div className="bg-amber-50 border-l-4 border-amber-500 p-4 mb-6 rounded-r shadow-sm flex items-start">
          <AlertCircle className="text-amber-500 w-6 h-6 mr-3 mt-1" />
          <div>
            <h3 className="font-bold text-amber-800">{seasonalAlert.title}</h3>
            <p className="text-amber-700">{seasonalAlert.message}</p>
          </div>
        </div>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-center">
          <div className="p-3 bg-blue-100 rounded-full mr-4 text-blue-600">
            <TrendingUp size={24} />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium">Ventas Totales</p>
            <p className="text-2xl font-bold text-slate-800">${totalSales.toLocaleString()}</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-center">
          <div className="p-3 bg-purple-100 rounded-full mr-4 text-purple-600">
            <ShoppingBag size={24} />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium">Pedidos Activos</p>
            <p className="text-2xl font-bold text-slate-800">{activeOrders}</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-center">
          <div className="p-3 bg-green-100 rounded-full mr-4 text-green-600">
            <Users size={24} />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium">Clientes Totales</p>
            <p className="text-2xl font-bold text-slate-800">{clients.length}</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-center">
          <div className="p-3 bg-orange-100 rounded-full mr-4 text-orange-600">
            <Calendar size={24} />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium">Fecha</p>
            <p className="text-lg font-bold text-slate-800">{new Date().toLocaleDateString('es-CO')}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <h3 className="font-bold text-lg mb-4 text-slate-800">Accesos Rápidos</h3>
          <div className="grid grid-cols-2 gap-4">
             <button className="p-4 bg-slate-50 hover:bg-slate-100 rounded-lg text-left transition border border-slate-200">
                <span className="font-semibold block text-slate-700">Nueva Cotización</span>
                <span className="text-xs text-slate-500">Calcular costos rápido</span>
             </button>
             <button className="p-4 bg-slate-50 hover:bg-slate-100 rounded-lg text-left transition border border-slate-200">
                <span className="font-semibold block text-slate-700">Registrar Retazo</span>
                <span className="text-xs text-slate-500">Agregar sobrante útil</span>
             </button>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
            <h3 className="font-bold text-lg mb-4 text-slate-800">Estado de Producción</h3>
            <div className="space-y-3">
                {/* Simple summary of kanban */}
                <div className="flex justify-between items-center p-2 bg-red-50 rounded">
                    <span className="text-sm font-medium text-red-800">Esperando Aprobación</span>
                    <span className="bg-white px-2 py-0.5 rounded text-xs font-bold text-red-600 border border-red-200">
                        {orders.filter(o => o.status === OrderStatus.WAITING_APPROVAL).length}
                    </span>
                </div>
                <div className="flex justify-between items-center p-2 bg-blue-50 rounded">
                    <span className="text-sm font-medium text-blue-800">En Producción</span>
                    <span className="bg-white px-2 py-0.5 rounded text-xs font-bold text-blue-600 border border-blue-200">
                        {orders.filter(o => o.status === OrderStatus.PRODUCTION).length}
                    </span>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;