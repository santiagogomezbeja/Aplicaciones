import React, { useState, useEffect } from 'react';
import { Calculator, Save } from 'lucide-react';
import { getMaterials, addOrder, getClients } from '../services/dataService';
import { MACHINE_RATE_PER_MINUTE, DESIGN_RATE_PER_HOUR, PROFIT_MARGIN_PERCENTAGE } from '../constants';
import { Client, Material, OrderStatus } from '../types';

const Quoter: React.FC = () => {
  const [materials, setMaterials] = useState<Material[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  
  // Form State
  const [selectedMaterialId, setSelectedMaterialId] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [machineTime, setMachineTime] = useState<number>(10);
  const [designHours, setDesignHours] = useState<number>(0.5);
  const [width, setWidth] = useState<number>(10);
  const [height, setHeight] = useState<number>(10);
  const [selectedClientId, setSelectedClientId] = useState<string>('');
  const [description, setDescription] = useState<string>('');

  // Result State
  const [totalCost, setTotalCost] = useState<number>(0);
  const [finalPrice, setFinalPrice] = useState<number>(0);

  useEffect(() => {
    setMaterials(getMaterials());
    setClients(getClients());
    if (getMaterials().length > 0) setSelectedMaterialId(getMaterials()[0].id);
    if (getClients().length > 0) setSelectedClientId(getClients()[0].id);
  }, []);

  useEffect(() => {
    calculatePrice();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedMaterialId, quantity, machineTime, designHours, width, height]);

  const calculatePrice = () => {
    const material = materials.find(m => m.id === selectedMaterialId);
    if (!material) return;

    // 1. Material Cost (Area based simple estimation for quoting)
    const sheetArea = material.sheetWidth * material.sheetHeight;
    const cutArea = width * height;
    const materialCostPerUnit = (material.costPerSheet / sheetArea) * cutArea;
    const totalMaterialCost = materialCostPerUnit * quantity;

    // 2. Machine Cost
    const totalMachineCost = machineTime * MACHINE_RATE_PER_MINUTE;

    // 3. Design Cost
    const totalDesignCost = designHours * DESIGN_RATE_PER_HOUR;

    // Total Base Cost
    const cost = totalMaterialCost + totalMachineCost + totalDesignCost;
    setTotalCost(cost);

    // Final Price with Margin
    // Price = Cost / (1 - Margin%) to maintain true margin, or Cost * (1+Margin) for markup.
    // User prompt said: Cost + Margin. Usually implies Markup logic in simple terms, but let's use Margin on Cost.
    // Formula from prompt: Cost = (...) + Margin. This implies Cost + Profit.
    const price = cost / (1 - PROFIT_MARGIN_PERCENTAGE); 
    setFinalPrice(Math.round(price / 100) * 100); // Round to nearest 100 COP
  };

  const handleSaveQuote = () => {
    if (!description || !selectedClientId) return;
    
    addOrder({
      id: Date.now().toString(),
      clientId: selectedClientId,
      description,
      status: OrderStatus.DRAFT,
      createdAt: new Date().toISOString(),
      totalPrice: finalPrice,
      materialId: selectedMaterialId
    });
    alert('Cotización guardada como borrador!');
    setDescription('');
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-xl shadow-lg border border-slate-100 overflow-hidden">
        <div className="bg-slate-800 p-6 text-white flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Calculator size={24} /> Cotizador Inteligente
            </h2>
            <p className="text-slate-300 text-sm">Calcula costos reales basados en material y tiempo máquina.</p>
          </div>
        </div>

        <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Inputs */}
          <div className="space-y-4">
            <h3 className="font-semibold text-slate-700 border-b pb-2">Parámetros de Producción</h3>
            
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Material</label>
              <select 
                className="w-full border border-slate-300 rounded-md p-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                value={selectedMaterialId}
                onChange={(e) => setSelectedMaterialId(e.target.value)}
              >
                {materials.map(m => (
                  <option key={m.id} value={m.id}>{m.name} {m.thickness} - ${m.costPerSheet.toLocaleString()}</option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
               <div>
                <label className="block text-sm font-medium text-slate-600 mb-1">Ancho (cm)</label>
                <input 
                  type="number" 
                  className="w-full border border-slate-300 rounded-md p-2"
                  value={width}
                  onChange={(e) => setWidth(Number(e.target.value))}
                />
               </div>
               <div>
                <label className="block text-sm font-medium text-slate-600 mb-1">Alto (cm)</label>
                <input 
                  type="number" 
                  className="w-full border border-slate-300 rounded-md p-2"
                  value={height}
                  onChange={(e) => setHeight(Number(e.target.value))}
                />
               </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-600 mb-1">Cantidad</label>
                <input 
                  type="number" 
                  className="w-full border border-slate-300 rounded-md p-2"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-600 mb-1">Tiempo Máquina (min)</label>
                <input 
                  type="number" 
                  className="w-full border border-slate-300 rounded-md p-2"
                  value={machineTime}
                  onChange={(e) => setMachineTime(Number(e.target.value))}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Horas Diseño</label>
              <input 
                type="number" 
                step="0.5"
                className="w-full border border-slate-300 rounded-md p-2"
                value={designHours}
                onChange={(e) => setDesignHours(Number(e.target.value))}
              />
            </div>
          </div>

          {/* Results */}
          <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 flex flex-col justify-between">
            <div>
              <h3 className="font-semibold text-slate-700 border-b pb-2 mb-4">Desglose de Costos</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-500">Costo Base Producción:</span>
                  <span className="font-medium">${totalCost.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Margen ({PROFIT_MARGIN_PERCENTAGE * 100}%):</span>
                  <span className="font-medium">${(finalPrice - totalCost).toLocaleString()}</span>
                </div>
                <div className="pt-4 border-t border-slate-200 mt-2">
                  <div className="flex justify-between items-end">
                    <span className="text-lg font-bold text-slate-800">Precio Final:</span>
                    <span className="text-3xl font-bold text-indigo-600">${finalPrice.toLocaleString()}</span>
                  </div>
                  <p className="text-xs text-right text-slate-400 mt-1">Sugerido (Redondeado)</p>
                </div>
              </div>
            </div>

            <div className="mt-8 space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Asignar a Cliente</label>
                <select 
                  className="w-full bg-white border border-slate-300 rounded-md p-2 text-sm"
                  value={selectedClientId}
                  onChange={(e) => setSelectedClientId(e.target.value)}
                >
                  {clients.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Descripción</label>
                <input
                  type="text"
                  placeholder="Ej: Llaveros día del padre"
                  className="w-full bg-white border border-slate-300 rounded-md p-2 text-sm"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>
              <button 
                onClick={handleSaveQuote}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center gap-2 transition"
              >
                <Save size={18} /> Guardar Pedido
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Quoter;